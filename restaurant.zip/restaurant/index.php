<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8">
	<title>Restaurant</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<?php include 'header.php'; ?>
	<div id="contents">
		<div id="adbox">
			<img src="images/bg-adbox.jpg" alt="Img" width="100%">
			
		</div>
		<div class="highlight">
			<div class="clearfix">
				<div class="testimonial">
					<iframe width="auto" src="https://www.youtube.com/embed/SeaiInbr92k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
				</div>
				<h1>Welcome...<br> To Our Restaurant !!!</h1>
				<p>
					Lorem ipsum dolor sit amett<br> de Finibus Bonorum et Malorum.
				</p>
			</div>
		</div>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>
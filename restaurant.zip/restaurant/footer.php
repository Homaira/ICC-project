<div id="footer">
	<div id="footnote">
		<div class="clearfix">
			<div class="connect">
				<a href="#" class="facebook"></a>
				<a href="#" class="twitter"></a>
				<a href="#" class="googleplus"></a>
				<a href="#" class="pinterest"></a>
			</div>
			<p>
				© Copyright 2023. All Rights Reserved.
			</p>
		</div>
	</div>
</div>
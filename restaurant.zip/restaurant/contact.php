<!DOCTYPE HTML>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Contact - Law Firm</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<?php include 'header.php'; ?>
	<div id="contents">
		<div class="clearfix">
			<div class="sidebar">
				<div>
					<h2>Contact Info</h2>
					<ul class="contact">
						<li>
							<p>
								<span class="home"></span> <em>Restaurant<br></em> Dhanmondi, Dhaka.
							</p>
						</li>
						<li>
							<p class="phone">
								Phone: 000 222 999
							</p>
						</li>
						
						<li>
							<p class="mail">
								Email: info@gmail.com
							</p>
						</li>
					</ul>
				</div>
			</div>
			<div class="main">
				<h1>Contact</h1>
				<h2>Send Us a Quick Message</h2>

				<form action="index.html" method="post" class="message">
					<label>First Name</label>
					<input type="text" value="">
					<label>Last Name</label>
					<input type="text" value="">
					<label>Email Address</label>
					<input type="text" value="">
					<label>Message</label>
					<textarea></textarea>
					<input type="submit" value="Send Message">
				</form>
			</div>
		</div>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>
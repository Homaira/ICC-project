<!DOCTYPE HTML>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Practices - Law Firm</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<?php include 'header.php'; ?>
	<div id="contents">
		<div class="clearfix">
			<div class="sidebar">
				<div>
					<h2>Practices</h2>
					<ul>
						<li>
							<a href="post.html">Prenuptial Agreement</a>
						</li>
						<li>
							<a href="post.html">Marriage</a>
						</li>
						<li>
							<a href="post.html">Divorce</a>
						</li>
					</ul>
				</div>
				<div>
					<h2>Client Testimonials</h2>
					<p>
						&ldquo;The best family lawyers in the city so far. Me and my ex-wife didn’t have any<br> problems settling the terms and agreement. Everything went so smoothly. We’re both very happy.&rdquo; <span>- Jared Greene</span>
					</p>
				</div>
			</div>
			<div class="main">
				<h1>Practices</h1>
				<p>
					This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text. You can remove any link to our website from this website template, you're free to use this website template without linking back to us. If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forums/">Forums</a>.
				</p>
				<ul class="practices">
					<li class="frame5">
						<a href="post.html" class="box"><img src="images/prenuptial.jpg" height="198" width="265"><span>Prenuptial Agreement</span></a>
					</li>
					<li class="frame5">
						<a href="post.html" class="box"><img src="images/bride.jpg" height="198" width="265"><span>Marriage</span></a>
					</li>
					<li class="frame5">
						<a href="post.html" class="box"><img src="images/divorce.jpg" height="198" width="265"><span>Divorce</span></a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>
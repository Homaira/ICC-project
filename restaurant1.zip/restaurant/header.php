<div id="header">
	<div class="clearfix">
		<div class="logo">
			<a href="index.html"><img src="images/logo.png" alt="LOGO" height="auto" width="60"></a>
		</div>
		<ul class="navigation">
			<li class="active">
				<a href="index.php">Home</a>
			</li>
			<li>
				<a href="about.php">About</a>
			</li>
			<li>
				<a href="menu.php">Menu</a>
			</li>
			<li>
				<a href="contact.php">Contact</a>
			</li>
		</ul>
	</div>
</div>
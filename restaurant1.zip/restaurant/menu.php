<!DOCTYPE HTML>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Menu</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<?php include 'header.php'; ?>
	<div id="contents">
		<div class="clearfix">
			<div class="sidebar">
				<div>
					<h2>Our Menu</h2>
					<ul>
						<li>
							<a href="post.html">Breakfast</a>
						</li>
						<li>
							<a href="post.html">Lunch</a>
						</li>
						<li>
							<a href="post.html">Dinner</a>
						</li>
					</ul>
				</div>
				<div>
					<h2>Menu</h2>
					<p>
						&ldquo;n fermentum elementum diam vel suscipit. Sed convallis id nisl non cursus. Nunc justo mauris, finibus nec arcu id, condimentum interdum lorem. Ut pharetra lectus eget dignissim efficitur. Nunc luctus, ipsum at tempor dignissim, libero enim pulvinar mi, nec commodo arcu mi a ante.&rdquo; <span>- Restaurant</span>
					</p>
				</div>
			</div>
			<div class="main">
				<h1>Order Now</h1>
				<p>
					Donec tincidunt orci in mattis tristique. Curabitur eget nisi nec ipsum efficitur scelerisque cursus a diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam nec volutpat leo. Nunc vel dolor mauris. Donec eget erat eget felis condimentum iaculis sed vel elit. Suspendisse a porta purus. Mauris eleifend placerat venenatis. 
				</p>
				<ul class="practices">
					<li class="frame5">
						<a href="#" class="box"><img src="images/item1.jpg" height="198" width="265"><span>Item One</span></a>
					</li>
					<li class="frame5">
						<a href="#" class="box"><img src="images/item2.jpg" height="198" width="265"><span>Item Two</span></a>
					</li>
					<li class="frame5">
						<a href="#" class="box"><img src="images/item3.jpg" height="198" width="265"><span>Item Three</span></a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>
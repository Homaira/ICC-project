<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8">
	<title>Restaurant</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<?php include 'header.php'; ?>
	<div id="contents">
		<div id="adbox">
			<img src="images/bg-adbox.jpg" alt="Img" width="100%">
			
		</div>
		<div class="highlight">
			<div class="clearfix">
				<h1>Welcome...<br> To Our Restaurant !!!</h1>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec accumsan massa gravida est congue pellentesque. Mauris id est lacus. Praesent at dapibus libero. Praesent varius quam eget orci sagittis, sed maximus massa blandit. Donec sit amet orci congue, sodales justo a, rutrum urna. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Morbi iaculis, ex at pulvinar gravida, sem arcu commodo felis, a rutrum turpis tortor in nisi. Integer et lorem et erat dignissim sagittis.

				Donec tincidunt orci in mattis tristique. Curabitur eget nisi nec ipsum efficitur scelerisque cursus a diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam nec volutpat leo. Nunc vel dolor mauris. Donec eget erat eget felis condimentum iaculis sed vel elit. Suspendisse a porta purus. Mauris eleifend placerat venenatis. </p>
			</div>
			
		</div>
		<div class="highlight">
			<div class="clearfix">
				<iframe width="100%" height="350" src="https://www.youtube.com/embed/SeaiInbr92k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
			</div>
		</div>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>
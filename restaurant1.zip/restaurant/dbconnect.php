<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: ". $conn->connect_error);
}


// Taking all 5 values from the form data(input)
$full_name =  $_REQUEST['full_name'];
$email = $_REQUEST['email'];
$message =  $_REQUEST['message'];




$sqlquery = "INSERT INTO customer VALUES ('$full_name', '$email', '$message')";

if ($conn->query($sqlquery) === TRUE) {
	// echo "record inserted successfully";
	header("Location: contact.php" );
    exit;
} else {
	echo "Error: " . $sqlquery . "<br>" . $conn->error;
}

// Close connection
mysqli_close($conn);

?>
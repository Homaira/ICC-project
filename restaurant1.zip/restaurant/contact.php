<!DOCTYPE HTML>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Contact</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<?php include 'header.php'; ?>
	<div id="contents">
		<div class="clearfix">
			<div class="sidebar">
				<div>
					<h2>Contact Info</h2>
					<ul class="contact">
						<li>
							<p>
								<span class="home"></span> <em>Restaurant<br></em> Dhanmondi, Dhaka.
							</p>
						</li>
						<li>
							<p class="phone">
								Phone: 000 222 999
							</p>
						</li>
						
						<li>
							<p class="mail">
								Email: info@gmail.com
							</p>
						</li>
					</ul>
				</div>
			</div>
			<div class="main">
				<h1>Contact</h1>
				<h2>Send Us a Quick Message</h2>

				<form action="dbconnect.php" method="post" class="message">
					<label>Full Name</label>
					<input type="text" name="full_name" id="full_name" value="">
					<label>Email Address</label>
					<input type="text" name="email" id="email" value="">
					<label>Message</label>
					<textarea name="message" id="message"></textarea>
					<input type="submit" value="Send Message">
				</form>
			</div>
		</div>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>